"""Local SQL Server -> warehouse exercise using SQLite + DuckDB stand-ins."""
from __future__ import annotations
import json, os, re, sqlite3, sys, time
from pathlib import Path
import duckdb

ROOT = Path('/app')
DATA = ROOT / 'data'
DATA.mkdir(exist_ok=True)
SRC = DATA / 'source.db'
DWH = DATA / 'warehouse.duckdb'
TABLES = {
    'customers': ('customer_id', ['customer_id','first_name','last_name','email','phone','updated_at','is_test','merged_into']),
    'advances': ('advance_id', ['advance_id','customer_id','status','amount','updated_at']),
    'transactions': ('transaction_id', ['transaction_id','customer_id','advance_id','amount','created_at','updated_at']),
    'cards': ('card_id', ['card_id','customer_id','last4','updated_at']),
    'customer_history': ('history_id', ['history_id','customer_id','version','payload','created_at']),
    'scratch_import': ('row_id', ['row_id','payload'])
}


def source_conn():
    c=sqlite3.connect(SRC); c.row_factory=sqlite3.Row; c.execute('PRAGMA foreign_keys=ON'); return c

def seed():
    c=source_conn()
    c.executescript('''
    CREATE TABLE IF NOT EXISTS customers(customer_id INTEGER PRIMARY KEY, first_name TEXT, last_name TEXT, email TEXT, phone TEXT, updated_at INTEGER NOT NULL, is_test INTEGER DEFAULT 0, merged_into INTEGER, external_customer_id TEXT);
    CREATE TABLE IF NOT EXISTS advances(advance_id INTEGER PRIMARY KEY, customer_id INTEGER NOT NULL, status TEXT NOT NULL, amount REAL NOT NULL, updated_at INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS transactions(transaction_id INTEGER PRIMARY KEY, customer_id INTEGER NOT NULL, advance_id INTEGER, amount REAL NOT NULL, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS cards(card_id INTEGER PRIMARY KEY, customer_id INTEGER NOT NULL, last4 TEXT NOT NULL, updated_at INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS customer_history(history_id INTEGER PRIMARY KEY, customer_id INTEGER, version INTEGER, payload TEXT, created_at INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS scratch_import(row_id INTEGER PRIMARY KEY, payload TEXT);
    CREATE TABLE IF NOT EXISTS change_log(seq INTEGER PRIMARY KEY AUTOINCREMENT, table_name TEXT NOT NULL, row_key TEXT NOT NULL, operation TEXT NOT NULL, changed_at INTEGER NOT NULL);
    CREATE INDEX IF NOT EXISTS ix_change_log_table_seq ON change_log(table_name,seq);
    ''')
    if c.execute('SELECT COUNT(*) FROM customers').fetchone()[0] == 0:
        now=int(time.time())
        customers=[(1,'Ana','Lopez','ana@example.com','+51987654321',now,0,None,'EXT-001'),(2,'Ana','Lopez','ana@example.com','+51987654321',now,0,None,'EXT-001'),(3,'Luis','Testerman','luis@testerman.com','123',now,0,None,'EXT-003'),(4,'Demo','User','test@fundo.com','bad-phone',now,1,None,'TEST-004'),(5,'Marta','Diaz','marta@@example','+51 999',now,0,None,'EXT-005'),(6,'Ana','Lopez','ana@example.com','+51987654321',now,0,None,'EXT-006'),(7,'Rosa','Paz','rosa@company.com','+51911111111',now,0,None,'EXT-007')]
        c.executemany('INSERT INTO customers VALUES(?,?,?,?,?,?,?,?,?)',customers)
        c.executemany('INSERT INTO advances VALUES(?,?,?,?,?)',[(10,1,'funded',500,now),(11,2,'pending',100,now),(12,6,'paid_off',300,now),(13,7,'pending',50,now)])
        c.executemany('INSERT INTO transactions VALUES(?,?,?,?,?,?)',[(100,1,10,500,now-10000,now),(101,2,11,100,now-9000,now),(102,3,None,10,now-8000,now),(103,7,13,50,now-7000,now)])
        c.executemany('INSERT INTO cards VALUES(?,?,?,?)',[(20,2,'1111',now),(21,6,'2222',now),(22,7,'3333',now)])
        c.executemany('INSERT INTO customer_history VALUES(?,?,?,?,?)',[(1,1,1,'{"status":"created"}',now-500),(2,1,2,'{"status":"verified"}',now-400)])
        c.execute('INSERT INTO scratch_import VALUES(1,?)',('unused',))
        for t, key in [('customers','customer_id'),('advances','advance_id'),('transactions','transaction_id'),('cards','card_id'),('customer_history','history_id')]:
            for r in c.execute(f'SELECT {key} FROM {t}').fetchall(): c.execute('INSERT INTO change_log(table_name,row_key,operation,changed_at) VALUES(?,?,?,?)',(t,str(r[0]),'I',now))
        c.commit()
    c.close()

def init_dw():
    d=duckdb.connect(str(DWH))
    for t,(pk,cols) in TABLES.items():
        types=[]
        for col in cols:
            typ='VARCHAR'
            if col.endswith('_id') or col in ('version','updated_at','created_at','is_test','merged_into'): typ='BIGINT'
            if col in ('amount',): typ='DOUBLE'
            types.append(f'"{col}" {typ}')
        d.execute(f'CREATE TABLE IF NOT EXISTS {t} ({", ".join(types)}, PRIMARY KEY("{pk}"))')
    d.execute('CREATE TABLE IF NOT EXISTS sync_state(table_name VARCHAR PRIMARY KEY, last_seq BIGINT NOT NULL)')
    d.execute('CREATE TABLE IF NOT EXISTS customer_identity_map(source_customer_id BIGINT PRIMARY KEY, canonical_customer_id BIGINT NOT NULL, reason VARCHAR NOT NULL)')
    d.close()

def sync(fail_after=None):
    """Apply CDC log in a single warehouse transaction; advance checkpoint atomically."""
    s=source_conn(); d=duckdb.connect(str(DWH)); d.execute('BEGIN TRANSACTION')
    try:
        applied=0
        for t,(pk,cols) in TABLES.items():
            if t=='scratch_import': continue
            state=d.execute('SELECT last_seq FROM sync_state WHERE table_name=?',[t]).fetchone()
            last=state[0] if state else 0
            events=s.execute('SELECT seq,row_key,operation FROM change_log WHERE table_name=? AND seq>? ORDER BY seq',(t,last)).fetchall()
            maxseq=last
            for ev in events:
                seq,key,op=ev; maxseq=seq
                if op=='D': d.execute(f'DELETE FROM {t} WHERE "{pk}"=?',[int(key)])
                else:
                    row=s.execute(f'SELECT {", ".join(cols)} FROM {t} WHERE "{pk}"=?',[int(key)]).fetchone()
                    if row is None: d.execute(f'DELETE FROM {t} WHERE "{pk}"=?',[int(key)])
                    else:
                        vals=list(row)
                        d.execute(f'INSERT OR REPLACE INTO {t} ({", ".join(chr(34)+x+chr(34) for x in cols)}) VALUES ({", ".join(["?"]*len(cols))})',vals)
                applied+=1
                if fail_after is not None and applied>=fail_after: raise RuntimeError('Injected mid-run failure')
            d.execute('INSERT OR REPLACE INTO sync_state VALUES (?,?)',[t,maxseq])
        d.execute('COMMIT')
        return applied
    except Exception:
        d.execute('ROLLBACK'); raise
    finally: s.close(); d.close()

def log_change(c, table, key, op):
    c.execute('INSERT INTO change_log(table_name,row_key,operation,changed_at) VALUES(?,?,?,?)',(table,str(key),op,int(time.time())))

def resolve_duplicates():
    """Merge only exact external IDs. Never merge two protected customers; skip test data."""
    s=source_conn(); d=duckdb.connect(str(DWH)); now=int(time.time())
    rows=s.execute('SELECT customer_id,external_customer_id,is_test,email,last_name FROM customers ORDER BY customer_id').fetchall()
    protected={r[0] for r in s.execute("SELECT DISTINCT c.customer_id FROM customers c JOIN advances a USING(customer_id) WHERE lower(a.status) IN ('funded','paid_off')").fetchall()}
    groups={}
    for r in rows:
        cid,ext,is_test,email,last=r
        if is_test or (email or '').lower() in ('test@fundo.com','qa@fundo.com','demo@fundo.com'): continue
        if ext: groups.setdefault(ext,[]).append(cid)
    decisions=[]
    for ext, ids in groups.items():
        if len(ids)<2: continue
        protected_ids=[x for x in ids if x in protected]
        if len(protected_ids)>1:
            decisions.append(f'AMBIGUOUS {ext}: multiple protected customers {protected_ids}; no merge'); continue
        canonical=protected_ids[0] if protected_ids else min(ids)
        for duplicate in ids:
            if duplicate==canonical: continue
            # Ensure duplicate does not itself have protected advance; if canonical protected, safe to reassign; otherwise neither protected.
            s.execute('UPDATE cards SET customer_id=?,updated_at=? WHERE customer_id=?',(canonical,now,duplicate))
            s.execute('UPDATE transactions SET customer_id=?,updated_at=? WHERE customer_id=?',(canonical,now,duplicate))
            s.execute('UPDATE advances SET customer_id=?,updated_at=? WHERE customer_id=?',(canonical,now,duplicate))
            s.execute('UPDATE customers SET merged_into=?,updated_at=? WHERE customer_id=?',(canonical,now,duplicate))
            log_change(s,'customers',duplicate,'U')
            # Changed rows need their own CDC events for dependent tables.
            for rr in s.execute('SELECT card_id FROM cards WHERE customer_id=?',(canonical,)).fetchall(): log_change(s,'cards',rr[0],'U')
            for rr in s.execute('SELECT transaction_id FROM transactions WHERE customer_id=?',(canonical,)).fetchall(): log_change(s,'transactions',rr[0],'U')
            for rr in s.execute('SELECT advance_id FROM advances WHERE customer_id=?',(canonical,)).fetchall(): log_change(s,'advances',rr[0],'U')
            d.execute('INSERT OR REPLACE INTO customer_identity_map VALUES (?,?,?)',[duplicate,canonical,'exact external_customer_id'])
        decisions.append(f'MERGED {ids} -> {canonical} (exact external_customer_id)')
    s.commit(); s.close(); d.close()
    return decisions

def quality_report():
    s=source_conn(); d=duckdb.connect(str(DWH)); out=[]
    for t,(pk,cols) in TABLES.items():
        if t=='scratch_import': continue
        source_count=s.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0]
        dw_count=d.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0]
        missing=max(0,source_count-dw_count); stale=max(0,dw_count-source_count)
        out.append({'table':t,'source_rows':source_count,'warehouse_rows':dw_count,'missing_count':missing,'stale_count':stale,'pass':source_count==dw_count})
    # Key-level completeness + content checks on mutable current-state tables.
    for t,(pk,cols) in TABLES.items():
        if t=='scratch_import': continue
        source_keys={r[0] for r in s.execute(f'SELECT "{pk}" FROM {t}').fetchall()}
        dw_keys={r[0] for r in d.execute(f'SELECT "{pk}" FROM {t}').fetchall()}
        missing=source_keys-dw_keys; stale=dw_keys-source_keys
        if missing or stale: out.append({'table':t+'_keys','missing_keys':sorted(missing),'stale_keys':sorted(stale),'pass':False})
        # Compare full row values for matching keys, not only counts/keys.
        source_rows={r[0]:tuple(r) for r in s.execute(f'SELECT {", ".join(cols)} FROM {t}').fetchall()}
        warehouse_rows={r[0]:tuple(r) for r in d.execute(f'SELECT {", ".join(cols)} FROM {t}').fetchall()}
        mismatched=[]
        for key in sorted(source_keys & dw_keys):
            if source_rows[key] != warehouse_rows[key]: mismatched.append(key)
        out.append({'table':t+'_content','mismatched_keys':mismatched,'pass':not mismatched})
    s.close(); d.close(); return out

def validate():
    report=quality_report()
    failed=[x for x in report if not x['pass']]
    print('QUALITY CHECK:', 'PASS' if not failed else 'FAIL')
    for r in report: print(json.dumps(r,sort_keys=True))
    return not failed

def demo():
    seed(); init_dw()
    start=time.perf_counter(); n=sync(); elapsed=(time.perf_counter()-start)*1000
    print(f'INITIAL/CDC SYNC: applied_events={n}; elapsed_ms={elapsed:.2f} (measured locally)')
    print('DUPLICATE RESOLUTION:')
    for line in resolve_duplicates(): print(' -',line)
    sync(); print('POST-MERGE SYNC'); validate()
    # Idempotency: no new events, unchanged counts.
    before=[r['warehouse_rows'] for r in quality_report() if 'warehouse_rows' in r]
    second=sync(); after=[r['warehouse_rows'] for r in quality_report() if 'warehouse_rows' in r]
    print(f'IDEMPOTENCY: second_sync_events={second}; counts_unchanged={before==after}')
    # Incremental insert/update/delete across tables.
    s=source_conn(); now=int(time.time())
    s.execute('INSERT INTO customers VALUES(8,?,?,?,?,?,?,?,?)',('Nina','Quispe','nina@example.com','+51922222222',now,0,None,'EXT-008')); log_change(s,'customers',8,'I')
    s.execute('UPDATE advances SET status=?,updated_at=? WHERE advance_id=13',('paid_off',now)); log_change(s,'advances',13,'U')
    s.execute('DELETE FROM cards WHERE card_id=22'); log_change(s,'cards',22,'D'); s.commit(); s.close()
    print(f'INCREMENTAL SYNC: applied_events={sync()}'); print('AFTER INSERT/UPDATE/DELETE'); validate()
    # Failure atomicity: write a source change, inject failure, then replay.
    s=source_conn(); s.execute('UPDATE customers SET phone=?,updated_at=? WHERE customer_id=8',('+51933333333',now+1)); log_change(s,'customers',8,'U'); s.commit(); s.close()
    try: sync(fail_after=1)
    except RuntimeError as e: print('FAILURE RECOVERY: injected failure rolled back warehouse transaction:',e)
    print(f'REPLAY AFTER FAILURE: applied_events={sync()}'); validate()
    # Break warehouse on purpose, show detection, repair with CDC replay isn't possible for deliberate warehouse-only corruption;
    # explicit rebuild of affected table from source is the documented repair.
    d=duckdb.connect(str(DWH)); d.execute('DELETE FROM transactions WHERE transaction_id=103'); d.close()
    print('INTENTIONAL CORRUPTION DEMO (deleted warehouse transaction 103):'); validate()
    # Repair using deterministic table reconciliation snapshot (operator-triggered).
    rebuild_table('transactions'); print('AFTER REPAIR:'); validate()

def rebuild_table(table):
    s=source_conn(); d=duckdb.connect(str(DWH)); pk,cols=TABLES[table]
    rows=s.execute(f'SELECT {", ".join(cols)} FROM {table}').fetchall()
    d.execute('BEGIN TRANSACTION'); d.execute(f'DELETE FROM {table}')
    for row in rows:
        d.execute(f'INSERT INTO {table} VALUES ({", ".join(["?"]*len(cols))})',list(row))
    d.execute('COMMIT'); s.close(); d.close()

if __name__=='__main__':
    mode=sys.argv[1] if len(sys.argv)>1 else 'demo'
    if mode=='demo': demo()
    elif mode=='check': raise SystemExit(0 if validate() else 1)
    elif mode=='seed': seed(); init_dw(); print('seeded')
    elif mode=='sync': print('applied events:',sync())
    elif mode=='check-broken':
        d=duckdb.connect(str(DWH)); d.execute('DELETE FROM transactions WHERE transaction_id=(SELECT MIN(transaction_id) FROM transactions)'); d.close(); raise SystemExit(0 if validate() else 1)
    else: raise SystemExit(f'unknown command: {mode}')
